const http = require("http");
const httpProxy = require("http-proxy");
const reos = require("reos-guard");

const WAF_PORT = process.env.WAF_PORT || 8080;
const TARGET_BACKEND = process.env.TARGET_BACKEND || "http://127.0.0.1:8085";

// ==========================================
// 1. THREAT INTELLIGENCE & REPUTATION ENGINE
// ==========================================
class ThreatIntelEngine {
    constructor() {
        this.ipRequestCounts = new Map(); // IP -> { count, windowStart }
        this.knownMaliciousIPs = new Set([
            "192.0.2.1", "198.51.100.42"
        ]);
    }

    isKnownMalicious(ip) {
        return this.knownMaliciousIPs.has(ip);
    }

    checkRateLimit(ip, limit = 120, windowMs = 10000) {
        const now = Date.now();
        const record = this.ipRequestCounts.get(ip) || { count: 0, windowStart: now };

        if (now - record.windowStart > windowMs) {
            record.count = 1;
            record.windowStart = now;
        } else {
            record.count++;
        }

        this.ipRequestCounts.set(ip, record);

        return record.count <= limit;
    }
}

const threatIntel = new ThreatIntelEngine();

// ==========================================
// 2. BOT IDENTIFICATION ENGINE
// ==========================================

// Explicit bot & headless browser signatures (curl & wget excluded to allow CLI downloads)
const KNOWN_BOT_USER_AGENTS = [
    /python-requests/i, /python-urllib/i,
    /postmanruntime/i, /insomnia/i, /nikto/i, /sqlmap/i,
    /headlesschrome/i, /puppeteer/i, /phantomjs/i, /selenium/i,
    /scrapy/i, /axios/i, /go-http-client/i, /java\//i, /libwww-perl/i,
    /bytespider/i, /gptbot/i, /claudebot/i
];

function isBotRequest(req) {
    const userAgent = (req.headers["user-agent"] || "").trim();

    const isKnownBot = KNOWN_BOT_USER_AGENTS.some((pattern) => pattern.test(userAgent));
    if (isKnownBot) {
        return { isBot: true, reason: `Known bot signature detected in User-Agent (${userAgent})` };
    }

    return { isBot: false };
}

// ==========================================
// 3. INJECTION DETECTION ENGINE
// ==========================================
const INJECTION_PATTERNS = [
    // SQL Injection (SQLi)
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|EXEC|EXECUTE|TRUNCATE)\b|--|\/\*|\*\/|;\s*SELECT|OR\s+1=1|AND\s+1=1)/i,
    // Cross-Site Scripting (XSS)
    /(<script[^>]*>|javascript:|onerror\s*=|onload\s*=|eval\(|<iframe|<img[^>]+src[^\w]*=)/i,
    // Command Injection (OS Exec)
    /(;\s*(cat|ls|pwd|whoami|nc|bash|sh|cmd|powershell|curl|wget)\b|\||`|\$\()/i,
    // Path Traversal
    /(\.\.\/|\.\.\\|%2e%2e%2f|%2e%2e\/)/i
];

function detectInjection(dataString) {
    if (!dataString) return false;
    const decodedData = decodeURIComponent(dataString);
    return INJECTION_PATTERNS.some((pattern) => pattern.test(decodedData));
}

// Standard browser metadata headers that trigger false positives in generic regex checks
const SAFE_HEADERS = new Set([
    "accept",
    "accept-language",
    "accept-encoding",
    "user-agent",
    "host",
    "connection",
    "sec-ch-ua",
    "sec-ch-ua-mobile",
    "sec-ch-ua-platform",
    "sec-fetch-dest",
    "sec-fetch-mode",
    "sec-fetch-site",
    "upgrade-insecure-requests"
]);

function parseAndInspectPayload(req) {
    return new Promise((resolve) => {
        // 1. Inspect URL and Query Strings
        if (detectInjection(req.url)) {
            return resolve({ blocked: true, reason: "Injection payload detected in URL or Query String" });
        }

        // 2. Inspect Request Headers (skipping standard safe browser metadata headers)
        for (const [headerName, headerVal] of Object.entries(req.headers)) {
            if (SAFE_HEADERS.has(headerName.toLowerCase())) {
                continue;
            }

            if (typeof headerVal === "string" && detectInjection(headerVal)) {
                return resolve({ blocked: true, reason: `Injection payload detected in header: ${headerName}` });
            }
        }

        // 3. Inspect Body for POST/PUT/PATCH requests
        if (["POST", "PUT", "PATCH"].includes(req.method)) {
            let body = "";
            req.on("data", (chunk) => {
                body += chunk.toString();
                if (body.length > 1e6) { // 1MB payload limit
                    req.destroy();
                }
            });

            req.on("end", () => {
                if (detectInjection(body)) {
                    return resolve({ blocked: true, reason: "Injection payload detected in Request Body" });
                }
                req.bodyBuffer = Buffer.from(body);
                return resolve({ blocked: false });
            });
        } else {
            return resolve({ blocked: false });
        }
    });
}

function getClientIp(req) {
    const forwarded = req.headers["x-forwarded-for"];
    if (forwarded) {
        return forwarded.split(",")[0].trim();
    }
    return req.socket.remoteAddress || "127.0.0.1";
}

// ==========================================
// 4. PROXY SETUP & SECURITY HEADERS
// ==========================================
const proxy = httpProxy.createProxyServer({
    target: TARGET_BACKEND,
    changeOrigin: true,
    proxyTimeout: 5000
});

// Stream buffered body payload to backend if POST/PUT was inspected
proxy.on("proxyReq", (proxyReq, req) => {
    if (req.bodyBuffer) {
        proxyReq.write(req.bodyBuffer);
    }
});

proxy.on("error", (err, req, res) => {
    console.error("❌ Proxy Routing Error:", err.message);
    if (!res.headersSent) {
        res.writeHead(502, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Bad Gateway", message: "Backend unreachable" }));
    }
});

proxy.on("proxyRes", (proxyRes) => {
    delete proxyRes.headers["x-powered-by"];
    delete proxyRes.headers["server"];
    proxyRes.headers["X-Content-Type-Options"] = "nosniff";
    proxyRes.headers["X-Frame-Options"] = "DENY";
});

// ==========================================
// 5. MAIN WAF SERVER PIPELINE
// ==========================================
const wafServer = http.createServer(async (req, res) => {
    const clientIp = getClientIp(req);

    // STEP A: Threat Intelligence Check
    if (threatIntel.isKnownMalicious(clientIp)) {
        res.writeHead(403, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ error: "Access Denied", reason: "IP blocked due to explicit blocklist" }));
    }

    // STEP B: Rate Limiting Check
    if (!threatIntel.checkRateLimit(clientIp)) {
        res.writeHead(429, { "Content-Type": "application/json", "Retry-After": "10" });
        return res.end(JSON.stringify({ error: "Too Many Requests", reason: "Automated rate limit exceeded" }));
    }

    // STEP C: Bot Detection Rules
    const botCheck = isBotRequest(req);
    if (botCheck.isBot) {
        console.warn(`[BOT BLOCKED] IP: ${clientIp} -> Reason: ${botCheck.reason}`);
        res.writeHead(403, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ error: "Access Denied", reason: botCheck.reason }));
    }

    // STEP D: Injection Payload Inspection
    const injectionCheck = await parseAndInspectPayload(req);
    if (injectionCheck.blocked) {
        console.warn(`[INJECTION BLOCKED] IP: ${clientIp} -> Reason: ${injectionCheck.reason}`);
        res.writeHead(400, { "Content-Type": "application/json" });
        return res.end(JSON.stringify({ error: "Bad Request", reason: injectionCheck.reason }));
    }

    // STEP E: Enforce Reos-Guard Verification
    try {
        if (typeof reos === "function") {
            await reos(req, res);
        } else if (reos && typeof reos.verifyToken === "function") {
            const token = req.headers["x-reos-token"] || "";
            if (token) {
                await reos.verifyToken(token, "", clientIp);
            }
        }
    } catch (err) {
        console.error(`[WAF BLOCKED] Guard violation from IP: ${clientIp}. Reason:`, err.message);
        if (!res.headersSent) {
            res.writeHead(401, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ error: "Unauthorized", reason: "Security guard verification failed" }));
        }
        return;
    }

    // STEP F: Proxy Request to Target Backend
    console.log(`[REQUEST ALLOWED] IP: ${clientIp} -> ${req.method} ${req.url}`);
    proxy.web(req, res);
});

wafServer.listen(WAF_PORT, () => {
    console.log(`🛡️ WAF Active on http://localhost:${WAF_PORT}`);
});
