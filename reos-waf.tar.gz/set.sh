clear
apt update -y && apt upgrade -y
apt install nodejs npm -y
npm init -y
npm install reos-guard http-proxy
clear
node waf.js
