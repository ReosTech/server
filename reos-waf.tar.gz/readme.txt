hi this is reos reverse proxy waf
to set up run chmod +x set.sh then run ./set.sh
to host securely point your server to http://127.0.0.1:8085 and your hosting/tunneling service 
to http://localhost:8080
©️20266 Reos. all rights reserved
